package com.helloWorld.helloAlcione;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloAlcioneApplicationTests {

	@Test
	void contextLoads() {
	}

}
