package org.generation.blogPessoalAlcione;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlogPessoalAlcioneApplicationTests {

	@Test
	void contextLoads() {
	}

}
