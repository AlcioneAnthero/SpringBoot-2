package org.generation.blogPessoalAlcione;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlogPessoalAlcioneApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlogPessoalAlcioneApplication.class, args);
	}

}
